﻿using UnityEngine;

public interface ITakeDamage{
	void TakeDamage(int damage, GameObject instigator);
}