﻿using UnityEngine;
using System.Collections;

public class SlingshotProjectile : MonoBehaviour {



	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
